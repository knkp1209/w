var navs = [ {
    "title": "小程序信息管理",
    "icon": "fa-search",
    "spread": false,
    "href": "appletIM.php"
},{
    "title": "添加小程序",
    "icon": "fa-list",
    "spread": false,
    "href": "addApplet.php"
}];
